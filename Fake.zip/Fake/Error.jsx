import React from 'react'

export default function Error() {
    const Spanstyle={
        color:"red"
    }
  return (
    <div>
        <h1>
            page not found Error <span style={Spanstyle}>404</span>.....
        </h1>
    </div>
  )
}
