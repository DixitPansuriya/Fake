import React, { useState, useEffect } from 'react';

export default function Women() {
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [priceFilter, setPriceFilter] = useState('');

  useEffect(() => {
    fetch("https://fakestoreapi.com/products/category/women's clothing")
      .then(response => response.json())
      .then(data => setProducts(data))
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handlePriceFilter = (filter) => {
    setPriceFilter(filter);
  };

  const filteredProducts = products.filter(product =>
    product.title.toLowerCase().includes(searchTerm.toLowerCase()) &&
    (priceFilter === '' || (priceFilter === 'under' && product.price < 100) || (priceFilter === 'over' && product.price >= 100))
  );

  return (
    <div className="container">
      <h2 className="text-center my-4">Women's Clothing</h2>
      <div className="input-group mb-3">
        <input
          type="text"
          className="form-control"
          placeholder="Search products by name"
          value={searchTerm}
          onChange={handleSearch}
        />
      </div>
      <div className="btn-group mb-3" role="group" aria-label="Price Filter">
        <button type="button" className={`btn ${priceFilter === '' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => handlePriceFilter('')}>All</button>
        <button type="button" className={`btn ${priceFilter === 'under' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => handlePriceFilter('under')}>Under $100</button>
        <button type="button" className={`btn ${priceFilter === 'over' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => handlePriceFilter('over')}>Over $100</button>
      </div>
      <div className="row">
        {filteredProducts.map(product => (
          <div key={product.id} className="col-md-4 mb-4">
            <div className="card h-100">
              <img src={product.image} className="card-img-top" alt={product.title} />
              <div className="card-body">
                <h5 className="card-title">{product.title}</h5>
                <p className="card-text">${product.price}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
