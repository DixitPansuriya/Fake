import React from 'react';
import { Link } from 'react-router-dom';


export default function Header() {
  return (
    <div>
      <nav className="navbar sticky-top navbar-expand-lg bg-dark">
        <div className="container">
          <Link className="navbar-brand text-white" to="/">Mystore</Link>
          <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <i className="fas fa-bars text-white"></i>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav mr-auto w-100 justify-content-end">
              <li className="nav-item">
                <Link className="nav-link text-white" to="/">Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/Jewelry">Jewelry</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/Electronics">Electronics</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/Man">Men Clothing</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/Women">Women Clothing</Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  );
}
